num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))

if num1 > num2:
    print("O primeiro número é maior que o segundo.")
elif num1 < num2:
    print("O segundo número é maior que o primeiro.")
else:
    print("Os números são iguais.")
  