idade = float(input("Qual sua idade?"))

if idade <= 18:
    print("Vc é maior de idade")
else:
    print("Vc não é maior de idade")