num = float(input("Digite o número: "))


if num % 2 == 0:
    print ("O numero é par")
else:
    print ("O numero é impar")