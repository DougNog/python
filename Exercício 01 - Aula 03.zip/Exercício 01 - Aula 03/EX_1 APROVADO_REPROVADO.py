# média de dois numeros 

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))

if (nota1 + nota2) / 2 >= 6:
    print("Aprovado")
else:
    print("Reprovado")