num =int(input ("Digite um número: "))

num2 = num ** 2

print (f"O quadrado de {num} é {num2}.")

