base_triangulo = float(input("coloque a base do tiângulo: "))
altura_triangulo = float(input("coloque a altura do triângulo: "))

perimetro_triangulo = base_triangulo * 3
area_triangulo = (base_triangulo * altura_triangulo) / 2

print(f"o perimetro do triângulo é: {perimetro_triangulo}")
print(f"a área do triângulo é: {area_triangulo}")