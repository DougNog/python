num = int(input("Ingrese un número: "))
num2 = int(input("Ingrese otro número: "))

print("o usiario digitou o número: ", num, " e ", num2)