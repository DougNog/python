val1 = int(input("Informe o primeiro valor: "))
val2 = int(input("Informe o segundo valor: "))

temp = val1
val1 = val2
val2 = temp
print("O primeiro valor é: ",val1)
print("O segundo valor é: ",val2)