num = int(input("digite um numero: "))

sucessor = num + 1
antecessor = num - 1

print(f"o sucessor de {num} é {sucessor} e o antecessor é {antecessor}") 